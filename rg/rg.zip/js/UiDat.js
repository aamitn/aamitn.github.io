define((require, exports, module) => {
  const dat = require('dat.gui.min')

  module.exports = new dat.GUI()
})
